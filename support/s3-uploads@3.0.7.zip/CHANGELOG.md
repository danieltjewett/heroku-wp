# Changelog

## 2.1.0-RC2

- Remove `lib/aws-sdk` from repository [#305](https://github.com/humanmade/S3-Uploads/pull/305)
- Fix delete files on delete attachment [#307](https://github.com/humanmade/S3-Uploads/pull/307)
- Fix Imagick with s3 compatibility [#306](https://github.com/humanmade/S3-Uploads/pull/306)
